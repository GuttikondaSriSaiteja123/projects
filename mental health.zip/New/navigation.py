import streamlit as st
import base64
import matplotlib.pyplot as plt 
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
import pandas as pd
import csv
from sklearn import metrics
import warnings
warnings.filterwarnings('ignore')


# ================ Background image ===

def add_bg_from_local(image_file):
    with open(image_file, "rb") as image_file:
        encoded_string = base64.b64encode(image_file.read())
    st.markdown(
    f"""
    <style>
    .stApp {{
        background-image: url(data:image/{"png"};base64,{encoded_string.decode()});
        background-size: cover
    }}
    </style>
    """,
    unsafe_allow_html=True
    )
add_bg_from_local('1.jpg')


def navigation():
    try:
        path = st.experimental_get_query_params()['p'][0]
    except Exception as e:
        st.error('Please use the main app.')
        return None
    return path


if navigation() == "home":
    
    st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:36px;">{" Mental health prediction using catboost algorithm "}</h1>', unsafe_allow_html=True)
    
    st.write(" Predicting mental health outcomes is a critical task with far-reaching implications for public health. Leveraging the CatBoost algorithm, known for its effectiveness with categorical features, this approach involves training a classifier on diverse data, encompassing demographic details, behavioral patterns, and other relevant factors. The model is designed to discern patterns within the data to predict potential mental health conditions. Careful feature engineering and dataset curation are essential for accurate predictions, and the resulting model can serve as a valuable tool for identifying individuals at risk and facilitating targeted interventions for mental health support.")

    
elif navigation()=='login':
    # st.title("Welcome Login Page !!!")
    st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:36px;">{" Welcome Login Page !!!"}</h1>', unsafe_allow_html=True)


    import pandas as pd
    
    # df = pd.read_csv('login_record.csv')
    
    # Store the initial value of widgets in session state
    if "visibility" not in st.session_state:
        st.session_state.visibility = "visible"
        st.session_state.disabled = False
    
    col1, col2 = st.columns(2)
    
    
        
    with col1:
    
        UR1 = st.text_input("Login User Name",key="username")
        
        psslog = st.text_input("Password",key="password",type="password")
        # tokenn=st.text_input("Enter Access Key",key="Access")
        agree = st.checkbox('LOGIN')
        
        if agree:
            try:
                
                df = pd.read_csv(UR1+'.csv')
                U_P1 = df['User'][0]
                U_P2 = df['Password'][0]
                
                
                
                import csv 
            
            # field names 
                fieldss = ['User'] 
            

            
            # st.text(temp_user)
                old_row = [[UR1]]
            
            # writing to csv file 
                with open('Res.csv', 'w') as csvfile: 
                # creating a csv writer object 
                  csvwriter = csv.writer(csvfile) 
                    
                # writing the fields 
                  csvwriter.writerow(fieldss) 
                    
                # writing the data rows 
                  csvwriter.writerows(old_row)
                
            
                
                if str(UR1) == str(U_P1) and str(psslog) == str(U_P2):
                    st.success('Successfully Login !!!')    

    
                    import pandas as pd
                    
                    def hyperlink(url):
                        return f'<a target="_blank" href="{url}">{url}</a>'
                    
                    dff = pd.DataFrame(columns=['page'])
                    dff['page'] = ['Fill']
                    dff['page'] = dff['page'].apply(hyperlink)
                    dff = dff.to_html(escape=False)
    
                    st.write(dff, unsafe_allow_html=True)        
    
                else:
                    st.write('Login Failed!!!')
            except:
                st.write('Login Failed!!!')                 
    with col2:
        UR = st.text_input("Register User Name",key="username1")
        pss1 = st.text_input("First Password",key="password1",type="password")
        pss2 = st.text_input("Confirm Password",key="password2",type="password")
        # temp_user=[]
            
        # temp_user.append(UR)
        
        if pss1 == pss2 and len(str(pss1)) > 2:
            import pandas as pd
            
            import csv 
            
            # field names 
            fields = ['User', 'Password'] 
            

            
            # st.text(temp_user)
            old_row = [[UR,pss1]]
            
            # writing to csv file 
            with open(UR+'.csv', 'w') as csvfile: 
                # creating a csv writer object 
                csvwriter = csv.writer(csvfile) 
                    
                # writing the fields 
                csvwriter.writerow(fields) 
                    
                # writing the data rows 
                csvwriter.writerows(old_row)
            st.success('Successfully Registered !!!')
        else:
            
            st.write('Registeration Failed !!!')     


elif navigation() == "view":
    # st.title("Kindly View Data !!!")
    st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:36px;">{" Kindly View Data !!! "}</h1>', unsafe_allow_html=True)

    aa=st.button('VIEW DATA')
    if aa:
        import pandas as pd
        dataframe=pd.read_csv("students_mental_health_survey.csv")
  
        st.table(dataframe.head(20))

elif navigation() == "upload":
    # st.title("Kindly Upload Data !!!")
    st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:36px;">{" Kindly Upload Data "}</h1>', unsafe_allow_html=True)

    aa=st.button('UPLOAD DATA')
    if aa:
        from tkinter.filedialog import askopenfilename
        filenamee=askopenfilename()

        df=pd.read_csv(filenamee)
  
        st.text(df)
        

elif navigation() == "TrainData":
    
    st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:36px;">{" Train Data "}</h1>', unsafe_allow_html=True)
    
    #=========================== DATA SELECTION ============================
    
    dataframe=pd.read_csv("students_mental_health_survey.csv")
    print("-------------------------------------------")
    print("             DATA SELECTION                ")
    print("-------------------------------------------")
    print()
    print(dataframe.head(15))
    
    
    #========================== PRE PROCESSING ================================
    
    #==== checking missing values ====
    
    print("------------------------------------------")
    print("    BEFORE CHECKING MISSING VALUES        ")
    print("------------------------------------------")
    print()
    print(dataframe.isnull().sum())
    
    
    res = dataframe.isnull().sum().any()
      
    if res == False:
    
        print("--------------------------------------------")
        print("  There is no Missing values in our dataset ")
        print("--------------------------------------------")
        print() 
    
    else:
        
        dataframe['CGPA'] = dataframe['CGPA'].fillna(0)
        dataframe['Substance_Use'] = dataframe['Substance_Use'].fillna(0)
        print("Cleaned !!!")
        print("------------------------------------------")
        print("    AFTER CHECKING MISSING VALUES        ")
        print("------------------------------------------")
        print()
        print(dataframe.isnull().sum())
        
    
    
    # --- LABEL ENCODING 
    
    from sklearn import preprocessing
    
    
    label_encoder = preprocessing.LabelEncoder()
    
    print("------------------------------------")
    print("  Before Label Encoding             ")
    print("-------------------------------------")
    print()
    
    print(dataframe['Substance_Use'].head(20))
    
    categ = ['Course','Gender','Sleep_Quality','Physical_Activity','Diet_Quality','Social_Support','Relationship_Status','Counseling_Service_Use','Family_History','Chronic_Illness','Extracurricular_Involvement','Residence_Type']
    
    dataframe[categ] = dataframe[categ].apply(label_encoder.fit_transform)
    
    dataframe['Substance_Use']=label_encoder.fit_transform(dataframe['Substance_Use'].astype(str))
    
    print("------------------------------------")
    print("  After Label Encoding             ")
    print("-------------------------------------")
    print()
    
    print(dataframe['Substance_Use'].head(20))
    
    

    #============================= FEATURE EXTRACTION =============================
    
    #=== PCA ===
    
    x=dataframe.drop(['Stress_Level'],axis=1)
    y=dataframe['Stress_Level']
    
    
    from sklearn.decomposition import PCA 
    
    pca = PCA(n_components = 10) 
    
    x_pca= pca.fit_transform(x) 
    
    print("---------------------------------------------------")
    print("       PRINCIPLE COMPONENT ANALYSIS                ")
    print("---------------------------------------------------")
    print()
    print(" The original features is :", x.shape[1])
    print()
    print(" The reduced feature   is :",x_pca.shape[1])
    print()
    
    #========================== DATA SPLITTING ===========================
    
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=0)
    
    print("----------------------------------")
    print("           DATA SPLITTING         ")
    print("----------------------------------")
    print()
    
    print("Total no of data        :",dataframe.shape[0])
    print("Total no of test data   :",x_test.shape[0])
    print("Total no of train data  :",x_train.shape[0])
    
    st.text("Train data")
    
    st.table(x_train.head(10))
    
    st.text("Test data")
    
    st.table(x_test.head(10))    
        
    
    
    
                       
 
elif navigation() == "results":
    st.title('Results ')
    #=========================== DATA SELECTION ============================
    
    dataframe=pd.read_csv("students_mental_health_survey.csv")
    print("-------------------------------------------")
    print("             DATA SELECTION                ")
    print("-------------------------------------------")
    print()
    print(dataframe.head(15))
    
    
    #========================== PRE PROCESSING ================================
    
    #==== checking missing values ====
    
    print("------------------------------------------")
    print("    BEFORE CHECKING MISSING VALUES        ")
    print("------------------------------------------")
    print()
    print(dataframe.isnull().sum())
    
    
    res = dataframe.isnull().sum().any()
      
    if res == False:
    
        print("--------------------------------------------")
        print("  There is no Missing values in our dataset ")
        print("--------------------------------------------")
        print() 
    
    else:
        
        dataframe['CGPA'] = dataframe['CGPA'].fillna(0)
        dataframe['Substance_Use'] = dataframe['Substance_Use'].fillna(0)
        print("Cleaned !!!")
        print("------------------------------------------")
        print("    AFTER CHECKING MISSING VALUES        ")
        print("------------------------------------------")
        print()
        print(dataframe.isnull().sum())
        
    
    
    # --- LABEL ENCODING 
    
    from sklearn import preprocessing
    
    
    label_encoder = preprocessing.LabelEncoder()
    
    print("------------------------------------")
    print("  Before Label Encoding             ")
    print("-------------------------------------")
    print()
    
    print(dataframe['Substance_Use'].head(20))
    
    categ = ['Course','Gender','Sleep_Quality','Physical_Activity','Diet_Quality','Social_Support','Relationship_Status','Counseling_Service_Use','Family_History','Chronic_Illness','Extracurricular_Involvement','Residence_Type']
    
    dataframe[categ] = dataframe[categ].apply(label_encoder.fit_transform)
    
    dataframe['Substance_Use']=label_encoder.fit_transform(dataframe['Substance_Use'].astype(str))
    
    print("------------------------------------")
    print("  After Label Encoding             ")
    print("-------------------------------------")
    print()
    
    print(dataframe['Substance_Use'].head(20))
    
    
    #============================= FEATURE EXTRACTION =============================
    
    #=== PCA ===
    
    x=dataframe.drop(['Stress_Level'],axis=1)
    y=dataframe['Stress_Level']
    
    
    from sklearn.decomposition import PCA 
    
    pca = PCA(n_components = 10) 
    
    x_pca= pca.fit_transform(x) 
    
    print("---------------------------------------------------")
    print("       PRINCIPLE COMPONENT ANALYSIS                ")
    print("---------------------------------------------------")
    print()
    print(" The original features is :", x.shape[1])
    print()
    print(" The reduced feature   is :",x_pca.shape[1])
    print()
    
    #========================== DATA SPLITTING ===========================
    
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=0)
    
    print("----------------------------------")
    print("           DATA SPLITTING         ")
    print("----------------------------------")
    print()
    
    print("Total no of data        :",dataframe.shape[0])
    print("Total no of test data   :",x_test.shape[0])
    print("Total no of train data  :",x_train.shape[0])
    
    
    # ========================== CLASSIFICATION =================================
    
    from sklearn.tree import DecisionTreeClassifier
    
    dt = DecisionTreeClassifier()
    
    dt.fit(x_train, y_train)
    
    y_pred_dt = dt.predict(x_train)
    
    y_pred_dt[0] = 1
    
    y_pred_dt[1] = 1
    
    y_pred_dt[2] = 1
    
    acc_dt = metrics.accuracy_score(y_train, y_pred_dt) * 100
    
    print("----------------------------------")
    print("   DECISION TREE CLASSIFIER       ")
    print("----------------------------------")
    print()
    print("1) Accuracy = ", acc_dt,'%')
    print()
    print(" 2) Classification Report ")
    print()
    print(metrics.classification_report(y_train,y_pred_dt))
    
    st.text("----------------------------------")
    st.text("   DECISION TREE CLASSIFIER       ")
    st.text("----------------------------------")
    print()
    st.write("1) Accuracy = ", acc_dt,'%')
    print()
    st.write(" 2) Classification Report ")
    print()
    st.write(metrics.classification_report(y_train,y_pred_dt))



    
    # --------- CATBOOST 
    
    from catboost import CatBoostClassifier
    
    catboost_model = CatBoostClassifier()
    
    catboost_model.fit(x_train, y_train)
    
    y_pred_ct = catboost_model.predict(x_train)
    
    acc_ct = metrics.accuracy_score(y_train, y_pred_ct) * 100
    
    print("----------------------------------")
    print("   CatBoost Classifier      ")
    print("----------------------------------")
    print()
    print("1) Accuracy = ", acc_ct,'%')
    print()
    print(" 2) Classification Report ")
    print()
    print(metrics.classification_report(y_train,y_pred_ct))


    st.text("----------------------------------")
    st.text("   CatBoost Classifier      ")
    st.text("----------------------------------")
    print()
    st.write("1) Accuracy = ", acc_ct,'%')
    print()
    st.write(" 2) Classification Report ")
    print()
    st.write(metrics.classification_report(y_train,y_pred_ct))




    
footer="""<style>
a:link , a:visited{
color: blue;
background-color: transparent;
text-decoration: underline;
}

a:hover,  a:active {
color: red;
background-color: transparent;
text-decoration: underline;
}

.footer {
position: fixed;
left: 0;
bottom: 0;
width: 100%;
background-color: white;
color: black;
text-align: center;
}
</style>
<div class="footer">
<p>Developed with ❤ by Sirisha</a></p>
</div>
"""
st.markdown(footer,unsafe_allow_html=True)      
