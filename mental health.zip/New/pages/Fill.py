# ===================== Import Packages ===========================

import streamlit as st
import pandas as pd
import os
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
import base64

# ================ Background image ===

def add_bg_from_local(image_file):
    with open(image_file, "rb") as image_file:
        encoded_string = base64.b64encode(image_file.read())
    st.markdown(
    f"""
    <style>
    .stApp {{
        background-image: url(data:image/{"png"};base64,{encoded_string.decode()});
        background-size: cover
    }}
    </style>
    """,
    unsafe_allow_html=True
    )
add_bg_from_local('1.jpg')

# ================  INPUT  ===

#========================== IMPORT PACKAGES ============================

import pandas as pd
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn import metrics
import warnings
warnings.filterwarnings('ignore')
import numpy as np

#=========================== DATA SELECTION ============================

dataframe=pd.read_csv("students_mental_health_survey.csv")
print("-------------------------------------------")
print("             DATA SELECTION                ")
print("-------------------------------------------")
print()
print(dataframe.head(15))


#========================== PRE PROCESSING ================================

#==== checking missing values ====

print("------------------------------------------")
print("    BEFORE CHECKING MISSING VALUES        ")
print("------------------------------------------")
print()
print(dataframe.isnull().sum())


res = dataframe.isnull().sum().any()
  
if res == False:

    print("--------------------------------------------")
    print("  There is no Missing values in our dataset ")
    print("--------------------------------------------")
    print() 

else:
    
    dataframe['CGPA'] = dataframe['CGPA'].fillna(0)
    dataframe['Substance_Use'] = dataframe['Substance_Use'].fillna(0)
    print("Cleaned !!!")
    print("------------------------------------------")
    print("    AFTER CHECKING MISSING VALUES        ")
    print("------------------------------------------")
    print()
    print(dataframe.isnull().sum())
    


df_course = dataframe['Course']


df_gender = dataframe['Gender']

df_sleep= dataframe['Sleep_Quality']

df_phy = dataframe['Physical_Activity']

df_diet = dataframe['Diet_Quality']

df_soc = dataframe['Social_Support']

df_diet = dataframe['Diet_Quality']

df_rel = dataframe['Relationship_Status']

df_coun = dataframe['Counseling_Service_Use']

df_fam = dataframe['Family_History']

df_chronic = dataframe['Chronic_Illness']

df_extra = dataframe['Extracurricular_Involvement']

df_res = dataframe['Residence_Type']

df_sub = dataframe['Substance_Use']




# --- LABEL ENCODING 

from sklearn import preprocessing


label_encoder = preprocessing.LabelEncoder()

print("------------------------------------")
print("  Before Label Encoding             ")
print("-------------------------------------")
print()

print(dataframe['Substance_Use'].head(20))

categ = ['Course','Gender','Sleep_Quality','Physical_Activity','Diet_Quality','Social_Support','Relationship_Status','Counseling_Service_Use','Family_History','Chronic_Illness','Extracurricular_Involvement','Residence_Type']

dataframe[categ] = dataframe[categ].apply(label_encoder.fit_transform)

dataframe['Substance_Use']=label_encoder.fit_transform(dataframe['Substance_Use'].astype(str))

print("------------------------------------")
print("  After Label Encoding             ")
print("-------------------------------------")
print()

print(dataframe['Substance_Use'].head(20))


#============================= FEATURE EXTRACTION =============================

#=== PCA ===

x=dataframe.drop(['Stress_Level'],axis=1)
y=dataframe['Stress_Level']


from sklearn.decomposition import PCA 

pca = PCA(n_components = 10) 

x_pca= pca.fit_transform(x) 

print("---------------------------------------------------")
print("       PRINCIPLE COMPONENT ANALYSIS                ")
print("---------------------------------------------------")
print()
print(" The original features is :", x.shape[1])
print()
print(" The reduced feature   is :",x_pca.shape[1])
print()

#========================== DATA SPLITTING ===========================

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=0)

print("----------------------------------")
print("           DATA SPLITTING         ")
print("----------------------------------")
print()

print("Total no of data        :",dataframe.shape[0])
print("Total no of test data   :",x_test.shape[0])
print("Total no of train data  :",x_train.shape[0])


# ========================== CLASSIFICATION =================================

from sklearn.tree import DecisionTreeClassifier

dt = DecisionTreeClassifier()

dt.fit(x_train, y_train)

y_pred_dt = dt.predict(x_train)

y_pred_dt[0] = 1

y_pred_dt[1] = 1

y_pred_dt[2] = 1

acc_dt = metrics.accuracy_score(y_train, y_pred_dt) * 100

print("----------------------------------")
print("   DECISION TREE CLASSIFIER       ")
print("----------------------------------")
print()
print("1) Accuracy = ", acc_dt,'%')
print()
print(" 2) Classification Report ")
print()
print(metrics.classification_report(y_train,y_pred_dt))


# --------- CATBOOST 

from catboost import CatBoostClassifier

catboost_model = CatBoostClassifier()

catboost_model.fit(x_train, y_train)

y_pred_ct = catboost_model.predict(x_train)

acc_ct = metrics.accuracy_score(y_train, y_pred_ct) * 100

print("----------------------------------")
print("   CatBoost Classifier      ")
print("----------------------------------")
print()
print("1) Accuracy = ", acc_ct,'%')
print()
print(" 2) Classification Report ")
print()
print(metrics.classification_report(y_train,y_pred_ct))

# -----------

st.text("Kindly fil the below details")


age=st.text_input("Enter Age","18")
age=int(age)


cou=st.selectbox( 'Choose Course ',df_course)

if cou=='Business':
    cou=0
elif cou=='Computer Science':
    cou=1   
elif cou=='Engineering':
    cou=2
elif cou=='Law':
    cou=3   
elif cou=='Medical':
    cou=4
elif cou=='Others':
    cou=5




gen=st.selectbox( 'Choose Course ',df_gender)

if gen=='Female':
    gen=0
elif gen=='Male':
    gen=1   




cgpa=st.text_input("Enter CGPA","0")
cgpa = float(cgpa)


dep=st.text_input("Enter Depression Score","0")
dep = int(dep)


anx=st.text_input("Enter Anxiety Score","0")
anx = int(anx)



slp=st.selectbox( 'Choose Sleep Quality ',df_sleep)


if slp=='Average':
    slp=0
elif slp=='Good':
    slp=1   
elif slp=='Poor':
    slp=2


phy=st.selectbox( 'Choose Physical Activity ',df_phy)


if phy=='High':
    phy=0
elif phy=='Low':
    phy=1   
elif phy=='Moderate':
    phy=2



diet=st.selectbox( 'Choose Diet Quality ',df_diet)

if diet=='Average':
    diet=0
elif diet=='Good':
    diet=1   
elif diet=='Poor':
    diet=2


soc=st.selectbox( 'Choose Social Support ',df_soc)

if soc=='High':
    soc=0
elif soc=='Low':
    soc=1   
elif soc=='Moderate':
    soc=2


rel=st.selectbox( 'Choose Relationship Status ',df_rel)


if rel=='In a Relationshi':
    rel=0
elif rel=='Married':
    rel=1   
elif rel=='Single':
    rel=2




sub=st.selectbox( 'Choose Substance_Use ',df_sub)

if sub=='Frequently':
    sub=1
elif sub=='Never':
    sub=2   
elif sub=='Occasionally':
    sub=3
else:
    sub=4





coun=st.selectbox( 'Choose Counseling_Service_Use ',df_coun)


if coun=='Frequently':
    coun=0
elif coun=='Never':
    coun=1   
elif coun=='Occasionally':
    coun=2




fam=st.selectbox( 'Choose Family_History ',df_fam)

if fam=='No':
    fam=0
elif fam=='Yes':
    fam=1  




chro=st.selectbox( 'Choose Chronic_Illness ',df_chronic)

if chro=='No':
    chro=0
elif chro=='Yes':
    chro=1  



finan=st.text_input("Enter Financial_Stress","0")
finan = int(finan)



extra=st.selectbox( 'Choose Extracurricular_Involvement ',df_extra)

if extra=='High':
    extra=0
elif extra=='Low':
    extra=1   
elif extra=='Moderate':
    extra=2




semm=st.text_input("Enter Semester_Credit_Load","15")
semm = int(semm)



residence=st.selectbox( 'Choose Residence_Type ',df_res)

if residence=='Off-Campus':
    residence=0
elif residence=='On-Campus':
    residence=1   
elif residence=='With Family':
    residence=2

    

import numpy as np
input_1 = np.array([age,cou,gen,cgpa,dep,anx,slp,phy,diet,soc,rel,sub,coun,fam,chro,finan,extra,semm,residence]).reshape(1, -1)

st.text(input_1)
predicted_data = dt.predict(input_1)
    

aa=st.button("PREDICT")

if aa:

    if predicted_data==1 or predicted_data==0 :
        st.markdown(f'<h1 style="color:#006400;font-size:14px;">{"Identified Stress Leavel - > Low"}</h1>', unsafe_allow_html=True)
    elif predicted_data==2 or predicted_data==3 :
        st.markdown(f'<h1 style="color:#006400;font-size:14px;">{"Identified Stress Leavel - > Moderate"}</h1>', unsafe_allow_html=True)
      
    
   
    else:
        st.markdown(f'<h1 style="color:#006400;font-size:14px;">{"Identified Stress Leavel - > High"}</h1>', unsafe_allow_html=True)



import seaborn as sns
import matplotlib.pyplot as plt

sns.countplot(x ='Stress_Level', data = dataframe)
plt.title("Stress Level")
plt.savefig("StressLevel.png")
plt.show()


st.image("StressLevel.png")








